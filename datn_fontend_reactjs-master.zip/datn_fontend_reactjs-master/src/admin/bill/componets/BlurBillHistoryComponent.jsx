import React from 'react';

const BlurBillHistoryComponent = () => {
    return (
        <div className={"d-flex flex-column justify-content-center align-items-center"}>
            <div style={{
                height: 12,
                width: 100,
                backgroundColor: "#adb5bd"
            }}>

            </div>

        </div>
    );
};

export default BlurBillHistoryComponent;