import React from 'react';

// Trang này user cần login thì mới dược phép
const UserLogin = () => {
    return (
        <div style={{
            height: "500px"
        }} className={""}>
            <h1>
                test/auth-useredfdffddddddddddddđ

                dsds

            </h1>
        </div>
    );
};

export default UserLogin;