// const [show, setShow] = useState(false);
// const handleClose = () => setShow(false);
// const handleShow = () => setShow(true);
// const [validated, setValidated] = useState(false);

// const handleSubmit = (event) => {
//   const form = event.currentTarget;
//   if (form.checkValidity() === false) {
//     event.preventDefault();
//     event.stopPropagation();
//   }
//   setValidated(true);
// };
{/* <Form noValidate validated={validated} onSubmit={handleSubmit}>
                <Form.Group>
                  <h5>Giới tính</h5>
                  <Form.Check
                    required
                    label="Nam"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="Nữ"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <h5>Size</h5>
                  <Form.Check
                    required
                    label="37"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="38"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="39"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="40"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="41"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <h5>Màu</h5>
                  <Form.Check
                    required
                    label="Xanh"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="Đen"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <h5>Loại</h5>
                  <Form.Check
                    required
                    label="Thể thao"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="Thời trang"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <h5>Chất liệu</h5>
                  <Form.Check
                    required
                    label="Vải"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="Da"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <h5>Đế giày</h5>
                  <Form.Check
                    required
                    label="Đế cao su"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  />
                  <Form.Check
                    required
                    label="Đế nhựa"
                    feedback="Bạn chưa chọn"
                    feedbackType="invalid"
                  /> */}
{/* </Form.Group> */ }
{/* </Form> */ }
                    {/* // <div>
                    //    <Form.Label>Chọn khoảng giá</Form.Label>
                    //   <Form.Range  type="range" class="form-range" id="customRange1" min="500000" max="10000000" step="1" />
                    //   <input type="range" class="form-range" id="customRange1" min="500000" max="10000000" step="1">
                    // </div> */}