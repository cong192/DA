import cloudinary from 'cloudinary';

// Cấu hình Cloudinary
cloudinary.config({
  cloud_name: 'dieyhvcou',
  api_key: '526492658683127',
  api_secret: 'your-api-secret',
});
