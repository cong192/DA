// constants.js
export const COLORS = {
    primary: "#F37021",
    error: '#D11313',
    information: '#0569FF',
    success: '#3AC430',
    pending: '#d96300',
    backgroundcolor: '#FFE527',
    color:'#030200',
    backgroundcolor2:"#f3702110"
};
