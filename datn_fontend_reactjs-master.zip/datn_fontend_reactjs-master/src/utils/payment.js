export const genQrUrl = (amount,des) => {
    return `https://qr.sepay.vn/img?acc=68682581998&bank=TPB&amount=${amount}&des=${des}`;
};
