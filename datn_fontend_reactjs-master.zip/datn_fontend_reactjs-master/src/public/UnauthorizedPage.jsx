import React, {Component} from 'react';

const UnauthorizedPage = () => {
    return (
        <div>
            Public page
        </div>
    );
}


export default UnauthorizedPage;