package com.poly.app.infrastructure.constant;

public enum TypeTransaction {
    THANH_TOAN,
    HOAN_TIEN
}
