package com.poly.app.domain.model.base;

public interface IsIdentified {


    Integer getId();



}
