package com.poly.app.infrastructure.constant;

public enum Tag {
    NEW,
    HOT,
    FLASH_SALE,
    BEST_SALE

}
