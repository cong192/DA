package com.poly.app.infrastructure.exception;

public class MessageValidateConstants {

//    Authentication message

    public static final  String nameRequired = "Tên không được phép để trống";
    public static final  String emailRequired = "Email không được phép để trống";
    public static final  String usernameRequired = "Username không được phép để trống";
    public static final  String passwordRequired = "Mật khẩu không được phép để trống";
    public static final  String genderRequired = "Mật khẩu không được phép để trống";
    public static final  String birthDayRequired = "Ngày sinh không được phép để trống";
    public static final  String phoneNumberRequired = "Số điện thoại không được phép để trống";
    public static final  String phoneNumberInvalid = "Số điện thoại không được phép để trống";


}
