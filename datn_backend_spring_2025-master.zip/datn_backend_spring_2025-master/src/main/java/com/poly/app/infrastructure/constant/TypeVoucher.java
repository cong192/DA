package com.poly.app.infrastructure.constant;

public enum TypeVoucher {
    TAT_CA,
    CA_NHAN
}
