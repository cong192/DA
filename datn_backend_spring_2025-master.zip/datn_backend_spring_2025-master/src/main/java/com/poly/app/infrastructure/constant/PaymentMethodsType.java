package com.poly.app.infrastructure.constant;

public enum PaymentMethodsType {
    // Kieeur thanh toán
    THANH_TOAN_TRUOC,
    ZALO_PAY,
    COD,
    HOAN_TIEN

}

