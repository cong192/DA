package com.poly.app.infrastructure.constant;

public enum StatusReturn {
    CHO_XAC_NHAN,
    DA_XAC_NHAN,
    DA_TU_CHOI,
    CHO_TRA_HANG,
    DA_HUY
}
