package com.poly.app.infrastructure.constant;

public enum PaymentMethod {
    CHUYEN_KHOAN,
    TIEN_MAT
}
