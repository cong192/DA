package com.poly.app.domain.admin.voucher.response;

import com.poly.app.infrastructure.constant.Status;

import java.time.LocalDateTime;

public interface VoucherResponse {
//    Integer getId();
//    String getVoucherCode();
//    Integer getQuantity();
//    String getVoucherType();
//    Double getDiscountValue();
//    Double getDiscountMaxValue();
//    Double getBillMinValue();
//    LocalDateTime getStartDate();
//    LocalDateTime getEndDate();
//    Status getStatus();
}
