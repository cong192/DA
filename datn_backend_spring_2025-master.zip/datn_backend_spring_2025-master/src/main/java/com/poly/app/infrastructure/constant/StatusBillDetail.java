package com.poly.app.infrastructure.constant;

public enum StatusBillDetail {
    TON_TAI,
    KHONG_TON_TAI,
    TRA_HANG
}
