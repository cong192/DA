package com.poly.app.infrastructure.constant;

public enum TypeBill {
    ONLINE,
    OFFLINE,
}
