package com.poly.app.infrastructure.constant;

public enum SenderType {

    CUSTOMER,STAFF;


}
