package com.poly.app.infrastructure.constant;

public enum TypeNotification {
    HOA_DON
}
