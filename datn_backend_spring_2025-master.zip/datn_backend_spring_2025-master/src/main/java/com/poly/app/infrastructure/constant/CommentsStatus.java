package com.poly.app.infrastructure.constant;

public enum CommentsStatus {
    CHO_DUYET,
    DA_DUYET,
    DA_AN
}
