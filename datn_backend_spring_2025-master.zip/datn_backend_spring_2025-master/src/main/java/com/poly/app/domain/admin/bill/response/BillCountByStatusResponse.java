package com.poly.app.domain.admin.bill.response;

public interface BillCountByStatusResponse {

    Integer getStatus();

}
