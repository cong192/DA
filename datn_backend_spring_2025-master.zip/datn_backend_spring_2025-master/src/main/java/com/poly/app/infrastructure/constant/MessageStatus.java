package com.poly.app.infrastructure.constant;

public enum MessageStatus {

    SENT,SEEN;


}
