package com.poly.app.infrastructure.constant;

public enum PaymentMethodEnum {
    // Phương thức thanh toán
    TIEN_MAT,
    CHUYEN_KHOAN,
    VN_PAY,
    MOMO,
    ZALO_PAY,
    COD
}
