package com.poly.app.domain.model;

public enum StatusEnum {
    dang_kich_hoat,
    ngung_kich_hoat,
    chua_kich_hoat
}
