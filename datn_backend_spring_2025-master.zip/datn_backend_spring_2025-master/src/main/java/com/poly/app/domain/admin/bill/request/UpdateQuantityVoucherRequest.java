package com.poly.app.domain.admin.bill.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateQuantityVoucherRequest {
    Integer id;
    Integer quantity;
}
