package com.poly.app.infrastructure.constant;

public enum Status {
    HOAT_DONG,
    NGUNG_HOAT_DONG
}
