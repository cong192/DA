package com.poly.app.domain.model;

public enum TypePayments {
    THANH_TOAN,
    HOAN_TIEN
}
