package com.poly.app.infrastructure.constant;

public enum PayMentBillStatus {
    CHUA_THANH_TOAN,
    DA_THANH_TOAN,
    DA_HOAN_TIEN;
}
