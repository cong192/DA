package com.poly.app.infrastructure.constant;

public class PropertyKeys {

    public static final String API_ERROR = "api.error";
    public static final String PRODUCT_DETAIL_NOT_EXIST = "productDetail.not.exist";
    private PropertyKeys() {
        
    }
}
