package com.poly.app.infrastructure.listener;


import com.poly.app.domain.model.base.PrimaryEntity;
import jakarta.persistence.PrePersist;

import java.util.UUID;

public class CreatePrimaryEntityListener {

}
