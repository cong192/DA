package com.poly.app.infrastructure.constant;

public enum TypeValue {
    PHAN_TRAM,
    GIA_TIEN
}
