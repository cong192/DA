package com.poly.app.infrastructure.constant;

public enum DiscountType {
    PERCENT,
    MONEY
}
