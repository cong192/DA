package com.poly.app.domain.admin.bill.response;

public interface BillHistoryResponse {

    String getStaffName();
    String getCustomerName();
    String getBillCode();
    String getStatus();
    String getDescription();
    String getCreatedAt();

}
