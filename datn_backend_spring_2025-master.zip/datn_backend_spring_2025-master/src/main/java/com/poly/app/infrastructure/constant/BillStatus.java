package com.poly.app.infrastructure.constant;

public enum BillStatus {

    DA_HUY,
    CHO_XAC_NHAN,
    DA_XAC_NHAN,
    CHO_VAN_CHUYEN,
    DANG_VAN_CHUYEN,
    DA_GIAO_HANG,
    DA_THANH_TOAN,
    CHO_THANH_TOAN,
    DA_HOAN_THANH,
    TAO_DON_HANG,
    TRA_HANG, //9
    KHONG_TON_TAI, //10
    HUY_YEU_CAU_TRA_HANG,
    TU_CHOI_TRA_HANG,
    DANG_XAC_MINH;


}
