package com.poly.app.infrastructure.constant;

public enum RoleAccount {
    NHAN_VIEN,
    QUAN_LY,
    KHACH_HANG
}
