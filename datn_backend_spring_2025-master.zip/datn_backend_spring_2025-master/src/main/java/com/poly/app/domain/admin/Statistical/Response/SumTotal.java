package com.poly.app.domain.admin.Statistical.Response;

public interface SumTotal {

    Double getTotalMoney();
}
