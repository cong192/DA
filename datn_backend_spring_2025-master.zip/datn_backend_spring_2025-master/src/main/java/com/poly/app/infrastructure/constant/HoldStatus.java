package com.poly.app.infrastructure.constant;

public enum HoldStatus {
    HOLDING,    // Đang giữ
    RELEASED,   // Đã giải phóng
    CONFIRMED   // Đã xác nhận sử dụng
}
