package com.poly.app.infrastructure.constant;

public enum VoucherType {
    PRIVATE,
    PUBLIC
}
