package com.poly.app.infrastructure.constant;

public enum AccountStatus {
    HOAT_DONG, // 0
    NGUNG_HOAT_DONG, // 1
    CHUA_KICH_HOAT, // 2
}
