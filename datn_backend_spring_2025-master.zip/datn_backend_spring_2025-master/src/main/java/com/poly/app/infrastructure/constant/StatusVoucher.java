package com.poly.app.infrastructure.constant;

public enum StatusVoucher {
    SAP_DIEN_RA,
    DANG_DIEN_RA,
    DA_KET_THUC
}
